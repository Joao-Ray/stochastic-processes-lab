from pathlib import Path
import json,gzip,math,hashlib
import numpy as np
P=Path(__file__).resolve().parent;c=json.loads((P/'COMPLETE.json').read_text());assert c['N']==500
assert hashlib.sha256((P/'full_sets.jsonl.gz').read_bytes()).hexdigest()==c['records_sha256']
with gzip.open(P/'full_sets.jsonl.gz','rt') as f:r=[json.loads(x) for x in f]
assert len(r)==500 and [x['replication'] for x in r]==list(range(500)) and len({x['seed'] for x in r})==500
null=0;branches=0;max_endpoint_diff=0.
for x in r:
 d=x['rank']['decisions'];assert len(d)==251 and d[0]['lower']==0 and d[-1]['upper']==1
 assert all(a['upper']==b['lower'] for a,b in zip(d[:-1],d[1:]))
 assert d[-1]['accepted'] and not d[-1]['simulated']
 union=[]
 for cell in d:
  if cell['simulated']:
   null+=cell['simulations'];assert cell['pvalue']==(1+cell['exceedances'])/(cell['simulations']+1)
   assert cell['accepted']==(cell['pvalue']>max(0,.05-cell['tv_bound']))
  else:assert cell['accepted'] and cell['tv_bound']>=.05
  if cell['accepted']:
   if union and union[-1][1]==cell['lower']:union[-1][1]=cell['upper']
   else:union.append([cell['lower'],cell['upper']])
 comp=[{'lower':max(0,-math.log(b)/.5),'upper':None if a==0 else -math.log(a)/.5,'unbounded_upper':a==0} for a,b in reversed(union)]
 assert len(comp)==len(x['rank']['components'])==x['rank_components']
 for a,b in zip(comp,x['rank']['components']):
  assert a['unbounded_upper']==b['unbounded_upper']
  for key in ['lower','upper']:
   if a[key] is None:assert b[key] is None
   else:
    max_endpoint_diff=max(max_endpoint_diff,abs(a[key]-b[key]));assert math.isclose(a[key],b[key],rel_tol=1e-14,abs_tol=1e-14)
 branches+=len(comp)>1
 assert x['rank_hit']==any(a<=math.exp(-.5)<=b for a,b in union)
 assert x['rank_unbounded']==(union[0][0]==0)
 if x['rank_unbounded']:assert x['rank_union_length'] is None
 else:assert math.isclose(x['rank_union_length'],sum(z['upper']-z['lower'] for z in comp),rel_tol=1e-14,abs_tol=1e-14)
 assert x['rank']['hull']['upper']==comp[-1]['upper'] and x['rank']['hull']['lower']==comp[0]['lower']
def prop(h):
 n=len(h);k=sum(h);p=k/n;z=1.959963984540054;den=1+z*z/n;center=(p+z*z/(2*n))/den;radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return {'hits':int(k),'n':n,'rate':p,'mcse':math.sqrt(p*(1-p)/n),'wilson95':[center-radius,center+radius]}
def pair(a,b):
 d=np.array(a,dtype=float)-np.array(b,dtype=float)
 return {'n':len(d),'difference':float(d.mean()),'mcse':float(d.std(ddof=1)/math.sqrt(len(d))),'gains':sum(x and not y for x,y in zip(a,b)),'losses':sum(y and not x for x,y in zip(a,b))}
rankhit=[x['rank_hit'] for x in r];out={'scope':'exploratory complete-cell-set study on500 reused records, one sparse design, not CDF inversion or new outer data','N':500,'cells_per_record':251,'new_null_paths':null,'stored_decisions':500*251,'all_saved_decisions_verified':True,'independent_math_vs_numpy_log_max_endpoint_difference':max_endpoint_diff,'rank':{'coverage':prop(rankhit),'unbounded':prop([x['rank_unbounded'] for x in r]),'empty':0,'disconnected':branches,'maximum_components':max(x['rank_components'] for x in r),'finite_nonempty_n':sum(not x['rank_unbounded'] for x in r)},'comparators':{},'runtime_seconds':c['seconds']}
finite=[x['rank_union_length'] for x in r if not x['rank_unbounded']];out['rank']['finite_union_length_median']=float(np.median(finite)) if finite else None
hulls=[x['rank']['hull']['upper']-x['rank']['hull']['lower'] for x in r if not x['rank_unbounded']];out['rank']['finite_hull_length_median']=float(np.median(hulls)) if hulls else None
for name in ['profile','bootstrap_profile']:
 av=[x for x in r if x[name]['available']];hits=[x[name]['hit'] for x in av];allhits=[x[name]['available'] and x[name]['hit'] for x in r]
 common=[x for x in av if not x['rank_unbounded'] and not x[name]['empty'] and math.isfinite(x[name]['width'])]
 diffs=[x['rank_union_length']-x[name]['width'] for x in common]
 out['comparators'][name]={'available':len(av),'conditional_coverage':prop(hits),'all_attempt_success_and_coverage':prop(allhits),'empty':sum(x[name]['empty'] for x in av),'unbounded':sum(not math.isfinite(x[name]['width']) for x in av),'paired_hits_all':pair(rankhit,allhits),'paired_hits_common_available':pair([x['rank_hit'] for x in av],hits),'common_finite_nonempty_n':len(common),'common_finite_union_length_difference_median':float(np.median(diffs)) if diffs else None}
(P/'summary.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out,indent=2))
