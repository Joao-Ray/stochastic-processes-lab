from pathlib import Path
import sys,json,gzip,hashlib,time,math
import numpy as np
from src.ou_process import simulate_ou_exact
from src.ou_uncertainty import ar_statistics
from src.ou_monte_carlo import invert_cells
P=Path(__file__).resolve().parent;I=P.parent/'input/unpacked';old=I/'subprojects/ou-inference-study/audit-2026-11-06/literature/results/seed2026110601_r2_a0.5.jsonl.gz'
assert hashlib.sha256((P/'src/ou_monte_carlo.py').read_bytes()).hexdigest()=='ac015c700b02a031b8441b84fdc386cf486f269ea976c3e85128f54e1d1b0385'
with gzip.open(old,'rt') as f: rows=[json.loads(x) for x in f]
rng=np.random.default_rng(np.random.SeedSequence([2026110601,0,0]));initial=rng.standard_normal(2000)
latent=simulate_ou_exact(1.,0.,np.sqrt(2.),0.,.02,100,2000,rng);latent+=initial[:,None]*np.exp(-.02*np.arange(101));series=latent[:500,::25]
for i,x in enumerate(series):
 assert rows[i]['replication']==i and math.isclose(ar_statistics(x).phi,rows[i]['phi'],rel_tol=0,abs_tol=1e-12)
manifest={'protocol_sha256':hashlib.sha256((P/'PROTOCOL.txt').read_bytes()).hexdigest(),'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (P/'src').glob('*.py')},'input_record_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'N':500,'slope_replay_passed':500,'utc_started':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};(P/'LOCK.json').write_text(json.dumps(manifest,indent=2))
start=time.monotonic()
with gzip.open(P/'full_sets.jsonl.gz','wt') as f:
 for i,x in enumerate(series):
  seed=int(np.random.SeedSequence([202611081103,i]).generate_state(1,dtype=np.uint64)[0]);t=time.monotonic();a=invert_cells(x,.5,seed,399,.05,.04,5.)
  comp=a['components'];unbounded=any(c['unbounded_upper'] for c in comp);length=None if unbounded else sum(c['upper']-c['lower'] for c in comp)
  hit=any(c['lower']<=1 and (c['upper'] is None or 1<=c['upper']) for c in comp)
  row={'replication':i,'phi':rows[i]['phi'],'series':x.tolist(),'seed':seed,'rank':a,'rank_hit':hit,'rank_union_length':length,'rank_unbounded':unbounded,'rank_components':len(comp),'rank_seconds':time.monotonic()-t,'profile':rows[i]['methods']['profile'],'bootstrap_profile':rows[i]['methods']['bootstrap_profile']}
  f.write(json.dumps(row)+'\n')
  if (i+1)%100==0:print('completed',i+1,'seconds',time.monotonic()-start,flush=True)
  if time.monotonic()-start>300:raise RuntimeError('Prespecified time cap reached; partial results only')
(P/'COMPLETE.json').write_text(json.dumps({'N':500,'seconds':time.monotonic()-start,'records_sha256':hashlib.sha256((P/'full_sets.jsonl.gz').read_bytes()).hexdigest()},indent=2));print((P/'COMPLETE.json').read_text())
