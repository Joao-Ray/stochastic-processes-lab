"""Distribution-free median uncertainty for finite, explicitly conditioned samples."""
import numpy as np
from scipy.stats import binom


def finite_median_summary(values, level=.95):
    """Median and a conservative order-statistic CI, requiring iid outer units.

    No first/second moment is required. The caller must describe any conditioning
    on returned/finite sets. This does not count those omitted outcomes as successes.
    None limits mean an unbounded Monte Carlo CI, not an infinite data value.
    """
    if not np.isfinite(level) or not 0 < level < 1:
        raise ValueError('level must be in (0,1)')
    x=np.asarray(values,dtype=float)
    if x.ndim!=1 or not np.isfinite(x).all():
        raise ValueError('values must be a finite one-dimensional sample')
    n=x.size
    if not n:
        return {'n':0,'median':None,'lower':None,'upper':None,'unbounded_lower':None,
                'unbounded_upper':None,'rank':None,'coverage_lower_bound':None}
    x=np.sort(x)
    # If k=0, no finite two-sided interval with this distribution-free level is
    # available. Conservative use of ppf handles exact-binomial equalities too.
    k=int(binom.ppf((1-level)/2,n,.5))
    full=k==0
    return {'n':int(n),'median':float(np.median(x)),
            'lower':None if full else float(x[k-1]),
            'upper':None if full else float(x[n-k]),
            'unbounded_lower':bool(full),'unbounded_upper':bool(full),'rank':k,
            'coverage_lower_bound':1. if full else float(1-2*binom.cdf(k-1,n,.5))}
