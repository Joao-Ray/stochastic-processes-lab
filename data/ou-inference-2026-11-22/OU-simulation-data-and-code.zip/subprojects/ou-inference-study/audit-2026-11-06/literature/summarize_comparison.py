"""Summarize all attempts, real pairs, widths and measured implementation costs."""
from pathlib import Path
from collections import Counter
import argparse,csv,gzip,hashlib,json,math
import numpy as np
from scipy.stats import norm

HERE=Path(__file__).resolve().parent
METHODS=['wald','profile','bootstrap_basic','bootstrap_profile','stationary_distribution']


def mean_se(values):
    a=np.asarray(values,dtype=float)
    if not len(a): return dict(n=0,mean=None,mc_se=None,pointwise_95=None)
    value=float(a.mean()); se=float(a.std(ddof=1)/np.sqrt(len(a))) if len(a)>1 else None
    return dict(n=len(a),mean=value,mc_se=se,pointwise_95=[value-1.96*se,value+1.96*se] if se is not None else None)


def probability(values):
    result=mean_se(values)
    result.pop('pointwise_95',None)
    n=result['n']
    if not n: return result
    p=result['mean']; z=norm.ppf(.975)
    result['mc_se']=float(np.sqrt(p*(1-p)/n))
    center=(p+z*z/(2*n))/(1+z*z/n)
    radius=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    result['wilson_95']=[float(center-radius),float(center+radius)]
    return result


def summarize(rows):
    result=dict(attempted=len(rows),methods={},paired_vs_stationary_distribution={},timing={})
    for method in METHODS:
        allsets=[r['methods'][method] for r in rows]
        available=[s for s in allsets if s['available']]
        finite=[s['width'] for s in available if not s['empty'] and np.isfinite(s['width'])]
        infinite=int(sum(np.isposinf(s['width']) for s in available))
        result['methods'][method]=dict(available=len(available),unavailable=len(rows)-len(available),
            failure_rate=probability([not s['available'] for s in allsets]),
            failure_reasons=dict(Counter(s['failure'] for s in allsets if not s['available'])),
            empty=sum(s['empty'] for s in available),unbounded=infinite,
            conditional_coverage=probability([s['hit'] for s in available]),
            success_and_coverage=probability([s['hit'] for s in allsets]),
            finite_nonempty_width=mean_se(finite),
            returned_mean_width=float('inf') if infinite else float(np.mean([s['width'] for s in available])) if available else None)
        if method != 'stationary_distribution':
            common=[(r['methods']['stationary_distribution'],r['methods'][method]) for r in rows
                if r['methods']['stationary_distribution']['available'] and r['methods'][method]['available']]
            common_finite=[(a,b) for a,b in common if not a['empty'] and not b['empty']
                           and np.isfinite(a['width']) and np.isfinite(b['width'])]
            result['paired_vs_stationary_distribution'][method]=dict(
                orientation='stationary_distribution minus '+method,
                joint_hit_difference=mean_se([int(r['methods']['stationary_distribution']['hit'])-int(r['methods'][method]['hit']) for r in rows]),
                common_available_hit_difference=mean_se([int(a['hit'])-int(b['hit']) for a,b in common]),
                common_finite_nonempty_width_difference=mean_se([a['width']-b['width'] for a,b in common_finite]))
    for key in rows[0]['timing']:
        result['timing'][key]=mean_se([r['timing'][key] for r in rows])
        result['timing'][key]['total_seconds']=float(sum(r['timing'][key] for r in rows))
    for method,entry in result['methods'].items():
        entry['finite_nonempty_width']['uncertainty_interpretation']='descriptive mean +/-1.96 sample SE; finite population moments not certified'
        if method=='wald':entry['finite_nonempty_width']['finite_population_mean_exists_in_ideal_gaussian_model']=False
    for contrast in result['paired_vs_stationary_distribution'].values():
        contrast['common_finite_nonempty_width_difference']['uncertainty_interpretation']='descriptive mean +/-1.96 sample SE; common-finite moment assumptions not certified'
    ss=[r['methods']['stationary_distribution'] for r in rows if r['methods']['stationary_distribution']['available']]
    result['numerics']=dict(max_estimated_cdf_error=max([s['max_cdf_error'] for s in ss],default=None),
        max_endpoint_residual=max([s['max_endpoint_residual'] for s in ss],default=None),
        nonmonotonic_screens=sum(s['nonmonotonic_screen'] for s in ss),
        disconnected=sum(len(s['components'])>1 for s in ss),
        positive_slopes_ge_one=sum(r['phi']>=1 for r in rows),
        truth_diagnostic_disagreements=sum(s['hit'] != (.025 <= s['cdf_at_truth'] <= .975) for s in ss),
        truth_diagnostic_policy='simulation-only; never an availability criterion in revised implementation')
    return result


def verify_reference(rows,reference_root):
    checks=[]
    for batch,seed in enumerate([2026110601,2026110602,2026110603],1):
        file=reference_root/f'batch{batch}/main/replications.csv.gz'
        if not file.exists():
            checks.append(dict(seed=seed,status='not_yet_available',path=str(file)))
            continue
        with gzip.open(file,'rt') as stream:
            ref={(r['scenario'],int(r['replication'])):r for r in csv.DictReader(stream)}
        selected=[r for r in rows if r['seed']==seed]
        max_phi_error=0.; max_endpoint_error=0.; mismatches=[]
        for row in selected:
            r=ref[row['scenario'],row['replication']]
            max_phi_error=max(max_phi_error,abs(float(r['phi'])-row['phi']))
            for method in METHODS[:-1]:
                s=row['methods'][method]
                if (r[method+'_available']=='True') != s['available'] or (r[method+'_hit']=='True') != s['hit']:
                    mismatches.append([row['scenario'],row['replication'],method,'available/hit'])
                if s['available']:
                    for endpoint in ['lower','upper']:
                        x=float(r[method+'_'+endpoint]); y=s[endpoint]
                        if np.isfinite(x) and np.isfinite(y): max_endpoint_error=max(max_endpoint_error,abs(x-y))
                        elif x!=y: mismatches.append([row['scenario'],row['replication'],method,endpoint])
        assert not mismatches and max_phi_error<1e-12 and max_endpoint_error<1e-8,(mismatches[:5],max_phi_error,max_endpoint_error)
        checks.append(dict(seed=seed,status='passed',records=len(selected),max_phi_error=max_phi_error,
                max_endpoint_error=max_endpoint_error,mismatches=mismatches,reference_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
    return checks


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,default=HERE/'results')
    parser.add_argument('--output',type=Path,default=HERE)
    parser.add_argument('--reference-root',type=Path,default=HERE.parent/'robustness')
    args=parser.parse_args()
    data_folder=args.input.resolve(); report_folder=args.output.resolve()
    report_folder.mkdir(parents=True,exist_ok=True)
    files=sorted(data_folder.glob('*.jsonl.gz'))
    assert len(files)==9, 'wait for all nine frozen runs'
    rows=[]
    for file in files:
        with gzip.open(file,'rt') as f: rows.extend(json.loads(line) for line in f)
    assert len(rows)==18000
    manifest=json.loads((data_folder/'manifest.json').read_text())
    for file in files:
        assert manifest['outputs'][file.name]==hashlib.sha256(file.read_bytes()).hexdigest()
    groups=Counter((r['seed'],r['scenario']) for r in rows)
    assert len(groups)==9 and set(groups.values())=={2000}
    assert len({(r['seed'],r['scenario'],r['replication']) for r in rows})==len(rows)
    assert all(0 <= r['replication'] < 2000 for r in rows)
    for row in rows:
        for method,s in row['methods'].items():
            if not s['available']:
                assert s['hit'] is False and s['width'] is None
                # Old source put the truth-membership check inside a failure handler.
                # If it ever fired, do not silently filter or claim comparative validity.
                assert 'truth membership' not in s['failure'], 'oracle diagnostic affected availability: rerun affected raw record before analysis'
                continue
            assert not math.isnan(s['width']) and s['width'] >= 0
            assert np.isfinite(s['lower']) and s['lower'] >= 0
            assert np.isfinite(s['upper']) or np.isposinf(s['upper'])
            assert s['upper'] >= s['lower']
            if s['empty']: assert not s['hit'] and s['width']==0
            if method=='stationary_distribution':
                assert s['hit']==any(lo<=1.<=hi for lo,hi in s['components'])
                assert s['width']==sum(hi-lo for lo,hi in s['components'])
                assert s['hit']==(.025 <= s['cdf_at_truth'] <= .975), 'distribution comparator failed independent numerical validation; no superiority analysis allowed'
            else:
                assert s['hit']==(not s['empty'] and s['lower']<=1.<=s['upper'])
    # A numerical warning in the old combined handler could have arisen from the
    # diagnostic CDF rather than construction. Reject rather than drop such rows.
    assert all(s['available'] or s['failure'].startswith('nonpositive slope:')
               for r in rows for m,s in r['methods'].items() if m=='stationary_distribution'), 'recompute and separate numerical failures before comparative conclusions'
    out=dict(source_files={str(f.name):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},
             reference_equivalence=verify_reference(rows,args.reference_root),by_batch={},pooled_by_design={})
    for seed in [2026110601,2026110602,2026110603]:
        for design in sorted(set(r['scenario'] for r in rows)):
            selection=[r for r in rows if r['seed']==seed and r['scenario']==design]
            out['by_batch'][f'{seed}/{design}']=summarize(selection)
    for design in sorted(set(r['scenario'] for r in rows)):
        out['pooled_by_design'][design]=summarize([r for r in rows if r['scenario']==design])
    out['width_uncertainty_policy']={'wald_population_mean':'infinite under the ideal finite-sample Gaussian model despite finite endpoints','sample_width_mc_se':'descriptive; no width moment assumption verified for every conditional selection','alternative':'../WIDTH_MEDIAN_REPORT.md: finite-conditional medians with order-statistic intervals','coverage_indicators':'bounded; coverage MCSE unchanged'}
    (report_folder/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
    def fmt(value):
        if value is None: return 'NA'
        if np.isinf(value): return 'infinite'
        return f'{value:.4f}'
    lines=['# Executed literature-method comparison','','All 18000 design-level attempts from the frozen protocol are retained. The two r=2 grids share paths, so this is 12000 independent base trajectories across durations and batches, with 6000 independent records per design. No cross-design pooling is performed.',
      'This is a stationary, noise-free distribution-inversion implementation validated against the 2014 working paper. It is not the authors\' software or a claimed replication of the uninspected 2017 full text.',
      '','[Protocol](PROTOCOL.md) | [Implementation and validation](IMPLEMENTATION.md) | [Complete JSON](summary.json) | [Run log](comparison.log)',
      '','## Pooled results by design','',
      'The denominator is 6000 per design, pooled over three independent seed batches. Empty returned sets count as available and miss. Domain failures and numerical failures count as unavailable and miss only for the explicitly named joint outcome. Widths below condition on finite nonempty sets; every returned-set mean is infinite whenever any unbounded set occurs.','',
      '| Design | Method | Available / attempts | Conditional coverage (MC SE) | Valid set and covers / all | Empty / unbounded | Finite sample width mean (descriptive s/sqrt(n)), n |',
      '|---|---|---|---|---|---|---|']
    for design,s in out['pooled_by_design'].items():
        for method,m in s['methods'].items():
            c=m['conditional_coverage']; j=m['success_and_coverage']; w=m['finite_nonempty_width']
            lines.append(f'| {design} | {method} | {m["available"]}/6000 | {fmt(c["mean"])} ({fmt(c["mc_se"])}) | {fmt(j["mean"])} | {m["empty"]}/{m["unbounded"]} | {fmt(w["mean"])} ({fmt(w["mc_se"])}), n={w["n"]} |')
    lines+=['','## Paired contrasts','','Signs are distribution inversion minus the stated baseline. The all-attempt joint outcome retains every trajectory. Common-subset coverage and finite-width contrasts answer conditional questions and are not procedure-level superiority guarantees. Pointwise 95% Monte Carlo intervals are unadjusted; no across-design ranking is certified.','',
            '| Design | Baseline | All-attempt joint hit difference (MC SE) | Common available difference (MC SE), n | Common finite width difference (descriptive s/sqrt(n)), n |',
            '|---|---|---|---|---|']
    for design,s in out['pooled_by_design'].items():
        for method,p in s['paired_vs_stationary_distribution'].items():
            j=p['joint_hit_difference']; c=p['common_available_hit_difference']; w=p['common_finite_nonempty_width_difference']
            lines.append(f'| {design} | {method} | {fmt(j["mean"])} ({fmt(j["mc_se"])}) | {fmt(c["mean"])} ({fmt(c["mc_se"])}), {c["n"]} | {fmt(w["mean"])} ({fmt(w["mc_se"])}), {w["n"]} |')
    lines+=['','## Each independent seed batch','','| Seed / design | Method | Available | Conditional coverage, Wilson 95% | Joint coverage | Failure rate |','|---|---|---|---|---|---|']
    for key,s in out['by_batch'].items():
        for method,m in s['methods'].items():
            c=m['conditional_coverage']; low,high=c['wilson_95']
            lines.append(f'| {key} | {method} | {m["available"]}/2000 | {fmt(c["mean"])}, [{fmt(low)},{fmt(high)}] | {fmt(m["success_and_coverage"]["mean"])} | {fmt(m["failure_rate"]["mean"])} |')
    lines+=['','## Failure and numerical accounting','']
    for design,s in out['pooled_by_design'].items():
        lines.append(f'- {design}: reasons={s["methods"]["stationary_distribution"]["failure_reasons"]}; numerical diagnostics={s["numerics"]}.')
    lines+=['','## Measured computational costs','','**Inference-only follow-up:** see [INFERENCE_TIMING.md](INFERENCE_TIMING.md) and the prespecified [TIMING_AMENDMENT.md](TIMING_AMENDMENT.md). These retime the first 100 records per seed/design without truth-CDF diagnostics; original audit-pipeline times below are retained for provenance.','','Single-process elapsed seconds; BLAS thread limits and versions are in results/manifest.json. Comparator evaluation and the original four procedures run on the same trajectories in the same process. Bootstrap_basic and bootstrap_profile share a B=399 bootstrap call and are reported as a combined cost. Costs exclude data generation, file I/O and prior validation; they include handling failed fits. The distribution-comparator timing also includes its per-record truth-CDF diagnostic, whereas baseline timing has no corresponding extra distribution integral. Treat these as audit-pipeline costs, not directly equal deployable-method or author-software timings. Other processes can cause timing variability. These measure this implementation, not author-software efficiency.','',
            '| Design | Procedure | Total seconds (6000 attempts) | Mean seconds (MC SE) |','|---|---|---|---|']
    for design,s in out['pooled_by_design'].items():
        for method,t in s['timing'].items():
            lines.append(f'| {design} | {method} | {t["total_seconds"]:.3f} | {t["mean"]:.6f} ({t["mc_se"]:.6f}) |')
    lines+=['','## Repeated-baseline equality check','',str(out['reference_equivalence']),
      '','The generated slopes, availability, coverage indicators and every available baseline endpoint are checked against the corresponding full main-run archives. Only same-trajectory method contrasts are paired. Independent durations and distinct seed batches are never paired by repetition label.',
      '','## Diagnostic correction and numerical sensitivity','','The original evaluation harness incorrectly allowed a truth-only diagnostic to alter availability. All 15082 returned sets passed the diagnostic and all 2918 unavailable rows had nonpositive slopes, so no observed interval was removed by that rule. The revised harness keeps truth diagnostics separate; the original source and hashes are preserved in sources/run_comparison_before_diagnostic_fix.py and diagnostic_reconciliation.json. See AMENDMENTS.md. The n=4 parameter-CDF screen was nonmonotonic on 96 records; a separate 257-point sensitivity check is recorded in nonmonotonic_check.json. No new trajectories or seed changes were introduced.',
      '','## Interpretation boundary','','See the audit synthesis for conclusions. Distribution theory under the exact stationary model does not establish robustness to fixed initial values or noise. The finite scanning grid for inversion, although checked against denser deterministic probes and direct truth tests, is not a certified exhaustive solver for all possible disconnected sets. Shorter finite-subset widths cannot offset missing intervals or unbounded sets.']
    lines += ['', '## Width-moment qualification, 2026-11-07', '', 'The ideal Gaussian Wald formula has infinite conditional population mean length despite finite interior endpoints; its sample s/sqrt(n) is descriptive, not a valid finite-population-mean MCSE. Common-finite contrasts need their own moment assumptions. See [proof and deterministic check](../WALD_WIDTH_MOMENTS.md) and [finite-conditional median intervals](../WIDTH_MEDIAN_REPORT.md). Coverage indicators are bounded and unchanged.']
    (report_folder/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('Complete: 18000 records, 9 runs, 3 designs; reference checks:',out['reference_equivalence'])

if __name__=='__main__': main()
