# Stationary distribution inversion: implementation and scope

The comparator is an independent numerical implementation derived from the
**2014 author working version**, not author-provided code. Bao, Ullah and Wang,
pp. 4–7, (2.5)–(2.7), define the slope estimator, its distribution and the
speed distribution conditional on a positive fitted slope. The stationary,
unknown-mean law is suitable here. Their real-data example instead fixes X0
and plugs in nuisance estimates (§3, footnote 9); that example is not reproduced.
The 2017 journal full text remains **未完成全文核验**. [Original working paper](https://economics.ucr.edu/repec/ucr/wpaper/201413.pdf).

## Mapping and our explicit algebra

Let n be the number of transitions, h=dt, phi=exp(-theta*h). In the source,
kappa=our theta, alpha=our intercept c, sigma_epsilon²=our q. The benchmark
estimates the equilibrium mean, so use the intercept-containing OLS slope,
not the known-mean ratio sum(x_k*x_(k+1))/sum(x_k²).

For z=(X1-X0,...,Xn-X0)', let U have ones on the first subdiagonal, and
P=I-11'/n. The lagged and subsequent observations, after a common translation,
are Uz and z. Therefore

$$\widehat\phi=\frac{z'Az}{z'Bz},\qquad
 A=(U'P+PU)/2,\quad B=U'PU.$$

B is positive semidefinite. For n>=3, the denominator is positive almost surely
under the nonsingular Gaussian model. With stationary start and innovation
variance q, the covariance of z/q^(1/2) is

$$C_{ij}(\phi)=\frac{\phi^{|i-j|}-\phi^i-\phi^j+1}{1-\phi^2},\quad 1\le i,j\le n.$$

A translation removes mu and a common scale cancels in the ratio; hence the
stationary sampling law depends on phi and n, not the unknown mu or sigma.
This does not hold for a fixed arbitrary X0 without further nuisance handling.

For C=LL' and eigenvalues lambda_j of L'(A-sB)L,

$$F_\phi(s)=P_\phi(\widehat\phi\le s)
=P\left\{\sum_j\lambda_j Z_j^2\le0\right\}.$$

The Gaussian characteristic function is the product of
(1-2it*lambda_j)^(-1/2). Rather than the source's analytic determinant recurrence,
we use dense symmetric eigenvalues and the continuous-phase expression

$$F_\phi(s)=\frac12-\frac1\pi\int_0^\infty
\frac{\sin\{\tfrac12\sum_j\arctan(2t\lambda_j)\}}
{t\exp\{\tfrac14\sum_j\log(1+4t^2\lambda_j^2)\}}\,dt.$$

Scaling every eigenvalue by the same positive constant leaves the probability
unchanged and improves quadrature conditioning. This formula is algebraically
equivalent to characteristic-function inversion for the same ratio law; it is
slower than specialized determinant recurrences, so our measured runtime cannot
be attributed to the authors' implementation.

For observed s>0, the decreasing log transformation gives the conditional speed
CDF at the observed estimate:

$$H_\phi(s)=\frac{1-F_\phi(s)}{1-F_\phi(0)}.$$

Retain candidates with .025<=H_phi(s)<=.975. The *ideal*, fully evaluated set
has 95% coverage conditional on the positive-slope event in this stationary
model, by the continuous distribution probability-integral transform. Its
all-attempt probability of returning a set containing truth is
.95*P(phi_hat>0). No finite-sample guarantee is claimed for an arbitrary fixed
start, sensor noise, or a numerically truncated/incorrect inversion.

## Boundary and numerical contract

`bao_stationary.py` evaluates C with `expm1`, retaining the limits C(0)=I+11'
and C(1)_(ij)=min(i,j). The latter follows by dividing the first-order numerator
and denominator at phi=1. Thus phi=0 maps to theta=infinity and phi=1 maps to
theta=0; we do not replace these limits with an arbitrary drift search cap.
The phi=1 endpoint is a stationary-law limit after subtracting X0, not a
stationary OU process with theta=0.

The implementation scans 17 equally spaced phi values over [0,1], refines every
bracketed .025/.975 crossing, and classifies components by midpoint membership.
Unbounded, empty, and disconnected sets have explicit representations.
It records integration-error estimates, endpoint residuals, nonmonotonicity,
and any disagreement between set membership and a direct generating-phi test.
A numerical scan cannot prove that no unbracketed narrow component exists.
Therefore this is a **numerically validated distribution-inversion comparator**,
not a certified exact continuous-set solver. A publication claiming guaranteed
numeric set coverage would still need a completeness or conservative-enclosure
argument and controlled rounding/quadrature error.

All nonpositive observed slopes are unavailable (the transformed estimator is
undefined), while slopes >=1 are retained for test inversion. Such slopes do
not become valid positive OU point estimates. Numerical failures are separated
from these domain failures and counted in all-attempt denominators.

## Validation and reproducibility

`validate_comparator.py` runs 47 checks recorded in `validation.json`:
OLS/quadratic-form and affine identities; a rank-two Cauchy probability with
closed form 2/pi*arctan(sqrt(b/a)); the covariance boundary limit; 100000
independent validation paths at each of n=4,20,100; fixed slope probes with
65 rather than 17 scanning points and tolerance 1e-10; and five values from
Table 4 Panel A, monthly column, printed p. 27 of the working paper. All five
original probabilities match at their printed four-decimal precision.
Simulation checks and agreement with a table support code reliability; they
are not a proof of the original mathematical distribution theory.

The method does not return a newly proposed point estimator. Bias and RMSE of
the interior conditional MLE remain the separately reported benchmark metrics.
The comparison evaluates sets, their availability, size, and computation time.
