# Implementation amendments

## A1: simulation-only truth diagnostic (2026-11-06, while frozen run executing)

Independent code review identified that the original runner treated disagreement
between numerical set membership at theta=1 and a direct CDF evaluation at the
known truth as an unavailable interval. This would make availability depend on
unknown truth, so it is not an appropriate deployable procedure.

The CDF/set constructor (`bao_stationary.py`) itself never uses the true theta;
the issue was the evaluation harness. The original runner is preserved in
`sources/run_comparison_before_diagnostic_fix.py`. Already-running computations
continue under that loaded source; original raw outputs are retained unchanged.
The revised `run_comparison.py` records direct truth agreement as a separate
simulation-only diagnostic and never changes a set or its availability on that
basis. Its source hash therefore differs from the historical execution hash;
the saved snapshot matches that hash.

Before any comparison is interpreted, `summarize_comparison.py` requires zero
such disagreements and zero ambiguous numerical-failure records in the old
run. If either occurs, the raw set must be regenerated under the corrected
harness, retained with its diagnostic, and the comparator marked as not passing
numerical validation; failed records must not be discarded to improve coverage.
This amendment does not change seeds, design points, bootstrap counts, or
stopping rules. The result of this check is reported in the final summary.

The summary now also validates row identity/counts, manifest checksums, NaN
versus infinite widths, empty-set hits and component lengths. Binomial results
report Wilson intervals only, removing an inconsistent duplicate normal-error
interval. Distribution-set width denotes the sum of component lengths, not the
convex-hull span; disconnected-set counts are retained.

## A2: nonmonotonic-CDF diagnostic follow-up (after all frozen runs)

The completed n=4 comparison flagged 96 nonmonotonic parameter-CDF screens,
all at observed slopes above 1.71. No truth-membership disagreements or
numerical failures occurred. Because a nonmonotonic CDF can produce more than
one accepted component, re-evaluate **all 96 flagged records** with 257 scanning
points and tolerance 1e-10, without generating any new paths or selecting by
coverage. Compare component counts, finite endpoints, total lengths and truth
membership with the original solver. Save every difference. This is an
implementation sensitivity audit, not an added favorable simulation batch or
a proof of exhaustive inversion. Original run outputs remain unchanged.

## A3: reporting-only serialization correction

The first summary attempt failed while serializing a NumPy integer count to JSON.
The complete traceback is kept in `summary-first-attempt.log`. Converting the
count to a Python integer fixed report generation; no simulation, interval,
denominator, or row was changed. The successful attempt is in `summary.log`.
