"""Stationary unknown-mean OU slope CDF: independent quadratic-form implementation.

Source: Bao, Ullah & Wang, 2014 working version, (2.5)--(2.7).
This uses the stationary Gaussian quadratic-form representation, not the
paper's faster analytic-determinant software and not its fixed-start plug-in CI.
Numerical integration is not a rigorous bound on floating-point error.
"""
from dataclasses import dataclass
from functools import lru_cache
import warnings
import numpy as np
from scipy.integrate import IntegrationWarning, quad
from scipy.linalg import cholesky, eigvalsh
from scipy.optimize import brentq


class NumericalFailure(RuntimeError):
    pass


@lru_cache(maxsize=16)
def ratio_matrices(n):
    if not isinstance(n, int) or n < 3:
        raise ValueError('at least three transitions')
    p = np.eye(n)-np.ones((n,n))/n
    u = np.eye(n, k=-1)
    numerator = (u.T @ p + p @ u)/2
    denominator = u.T @ p @ u
    return numerator, denominator


def difference_covariance(n, phi):
    """Cov(X_i-X_0, X_j-X_0)/innovation variance, including phi->1 limit.

    Translation invariance removes X0; at phi=1 the stationary-start slope
    law tends the zero-start Gaussian random-walk slope law with intercept.
    """
    if not 0 <= phi <= 1:
        raise ValueError('stationary nonnegative slope closure required')
    t = np.arange(1,n+1, dtype=float)
    if phi == 1:
        return np.minimum.outer(t,t)
    if phi == 0:
        return np.eye(n)+np.ones((n,n))
    logp = np.log(phi)
    return (np.expm1(abs(t[:,None]-t[None,:])*logp)
            -np.expm1(t[:,None]*logp)-np.expm1(t[None,:]*logp))/(-np.expm1(2*logp))


def quadratic_cdf_zero(eigenvalues, tolerance=1e-8):
    """P(sum lambda_i Z_i^2 <= 0) by continuous-phase CF inversion."""
    eig = np.asarray(eigenvalues, dtype=float)
    scale = np.max(abs(eig))
    if scale == 0:
        raise NumericalFailure('identically zero quadratic form')
    eig = eig/scale
    eig = eig[abs(eig) > 32*np.finfo(float).eps]
    if np.all(eig >= 0):
        return 0., 0.
    if np.all(eig <= 0):
        return 1., 0.
    def integrand(t):
        if t == 0:
            return float(eig.sum())
        z = 2*t*eig
        return float(np.sin(.5*np.arctan(z).sum()) * np.exp(-.25*np.log1p(z*z).sum())/t)
    with warnings.catch_warnings():
        warnings.simplefilter('error', IntegrationWarning)
        try:
            value, error = quad(integrand, 0, np.inf, epsabs=tolerance*np.pi,
                                epsrel=tolerance, limit=300)
        except IntegrationWarning as exc:
            raise NumericalFailure(str(exc)) from exc
    cdf = .5-value/np.pi
    error /= np.pi
    if not -10*tolerance <= cdf <= 1+10*tolerance or error > 10*tolerance:
        raise NumericalFailure(f'quadrature cdf={cdf}, estimated error={error}')
    return float(np.clip(cdf,0,1)), float(error)


def slope_cdf(observed, phi, n, tolerance=1e-8):
    a,b = ratio_matrices(n)
    l = cholesky(difference_covariance(n,phi), lower=True, check_finite=False)
    eig = eigvalsh(l.T @ (a-observed*b) @ l, check_finite=False)
    return quadratic_cdf_zero(eig, tolerance)


def conditional_speed_cdf(observed_phi, candidate_phi, n, tolerance=1e-8):
    """P(theta_hat <= observed theta_hat | phi_hat>0) at candidate phi."""
    if observed_phi <= 0:
        raise ValueError('log slope estimator unavailable')
    fx, ex = slope_cdf(observed_phi,candidate_phi,n,tolerance)
    f0, e0 = slope_cdf(0.,candidate_phi,n,tolerance)
    survival = 1-f0
    if survival < 1e-6:
        raise NumericalFailure('positivity event too rare for stable division')
    return float((1-fx)/survival), float(ex/survival+(1-fx)*e0/survival**2)


@dataclass
class DistributionSet:
    intervals: list
    max_cdf_error: float
    max_endpoint_residual: float
    nonmonotonic: bool
    evaluations: int

    @property
    def empty(self): return not self.intervals
    @property
    def width(self): return sum(hi-lo for lo,hi in self.intervals)
    def contains(self, theta):
        return any(lo <= theta <= hi for lo,hi in self.intervals)


def confidence_set(observed_phi, n, dt, level=.95, tolerance=1e-8, screen_size=17):
    """Scan full phi closure and refine every bracketed equal-tail crossing.

    This is a numerical set approximation, not a proof that the scanning grid
    captures every disconnected component. Callers must retain the diagnostic.
    Boundary phi=0 maps to an infinite theta endpoint; no finite theta cap.
    """
    if not np.isfinite(observed_phi) or observed_phi <= 0 or dt <= 0:
        raise ValueError('positive finite fitted slope and dt required')
    cache={}
    max_error=0.
    def cdf(phi):
        nonlocal max_error
        key=float(phi)
        if key not in cache:
            value,error=conditional_speed_cdf(observed_phi,key,n,tolerance)
            cache[key]=value
            max_error=max(max_error,error)
        return cache[key]
    grid=np.linspace(0,1,screen_size)
    values=np.array([cdf(p) for p in grid])
    nonmonotonic=bool(np.any(np.diff(values) < -20*tolerance))
    alpha=(1-level)/2
    roots=[]
    residuals=[]
    for target in (alpha,1-alpha):
        delta=values-target
        for k in range(len(grid)-1):
            if delta[k] == 0:
                root=float(grid[k])
            elif delta[k]*delta[k+1] < 0:
                root=float(brentq(lambda p: cdf(p)-target,grid[k],grid[k+1],
                                   xtol=tolerance,rtol=tolerance))
            else:
                continue
            roots.append(root)
            residuals.append(abs(cdf(root)-target))
    nodes=sorted(set([0.,1.]+roots))
    intervals=[]
    for left,right in zip(nodes[:-1], nodes[1:]):
        value=cdf((left+right)/2)
        if alpha <= value <= 1-alpha:
            lo=float(-np.log(right)/dt) if right < 1 else 0.
            hi=float(-np.log(left)/dt) if left > 0 else float('inf')
            intervals.append((lo,hi))
    return DistributionSet(sorted(intervals),max_error,max(residuals,default=0.),
                           nonmonotonic,len(cache))
