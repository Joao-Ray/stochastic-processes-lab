"""Run independent algebra/distribution checks before comparative outcomes."""
from pathlib import Path
import hashlib,json,sys,time
import numpy as np
from scipy.signal import lfilter
from bao_stationary import ratio_matrices, quadratic_cdf_zero, slope_cdf, confidence_set, difference_covariance, conditional_speed_cdf

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
from src.ou_uncertainty import ar_statistics


def main():
    start=time.perf_counter()
    checks=[]
    n=20
    values=np.sin(np.arange(n+1)*1.3)+.04*np.arange(n+1)**2
    a,b=ratio_matrices(n)
    z=values[1:]-values[0]
    ratio=float(z@a@z/(z@b@z))
    for scale,shift in [(1,0),(3,-7),(-2,4)]:
        actual=ar_statistics(scale*values+shift).phi
        assert abs(actual-ratio) < 1e-12
    checks.append(dict(check='OLS quadratic ratio and affine invariance',absolute_error=abs(actual-ratio),passed=True))
    for negative in [.1,1,4,100]:
        value,error=quadratic_cdf_zero([1,-negative])
        reference=2/np.pi*np.arctan(np.sqrt(negative))
        assert abs(value-reference) < 1e-8
        checks.append(dict(check='rank-two Cauchy special case',eigenvalues=[1,-negative],value=value,
                           reference=reference,absolute_error=abs(value-reference),quad_error=error,passed=True))
    covariance=difference_covariance(20,1-1e-9)
    assert np.max(abs(covariance-difference_covariance(20,1))) < 5e-6
    checks.append(dict(check='stationary centered phi->1 covariance limit',max_error=float(np.max(abs(covariance-difference_covariance(20,1)))),passed=True))
    for group,(n,phi) in enumerate([(4,np.exp(-.5)),(20,np.exp(-.1)),(100,np.exp(-.1))]):
        rng=np.random.default_rng(np.random.SeedSequence([2026110681,group]))
        count=100000
        values=np.empty((count,n+1))
        values[:,0]=rng.normal(size=count)
        values[:,1:]=(lfilter([1],[1,-phi],rng.normal(size=(count,n))*np.sqrt(1-phi*phi),axis=1)
                      +values[:,:1]*phi**np.arange(1,n+1))
        u=values[:,:-1]; y=values[:,1:]
        uc=u-u.mean(axis=1,keepdims=True)
        slopes=np.sum(uc*(y-y.mean(axis=1,keepdims=True)),axis=1)/np.sum(uc*uc,axis=1)
        for observed in [-.1,0.,.3,.7,.95,1.1]:
            predicted,error=slope_cdf(observed,phi,n)
            empirical=float(np.mean(slopes<=observed))
            se=np.sqrt(predicted*(1-predicted)/count)
            discrepancy=abs(empirical-predicted)
            passed=discrepancy <= 5*se+1/count
            checks.append(dict(check='independent stationary simulation CDF',n=n,phi=phi,
                observed_slope=observed,replications=count,predicted=predicted,empirical=empirical,
                mc_se=float(se),absolute_error=discrepancy,quad_error=error,passed=bool(passed)))
            assert passed, checks[-1]
        # Also test numerical intervals for a deterministic, outcome-independent probe grid.
        for observed in [.05,.2,.5,.8,1.,1.1]:
            interval=confidence_set(observed,n,.1)
            dense=confidence_set(observed,n,.1,tolerance=1e-10,screen_size=65)
            assert len(interval.intervals)==len(dense.intervals)
            residual=0.
            for first,second in zip(interval.intervals,dense.intervals):
                for x,y in zip(first,second):
                    if np.isfinite(x): residual=max(residual,abs(x-y))
                    else: assert x==y
            assert residual < 1e-5
            checks.append(dict(check='endpoint tolerance and denser scanning grid',n=n,observed_slope=observed,
                  intervals=interval.intervals,max_endpoint_difference=residual,
                  max_endpoint_equation_error=interval.max_endpoint_residual,
                  nonmonotonic=interval.nonmonotonic,passed=True))
    # Bao et al. (2014), printed p27, Table 4 Panel A, monthly column.
    for w, reference in [(-1,.0210),(0,.0612),(1,.1373),(5,.5467),(20,.9562)]:
        value,error=conditional_speed_cdf(np.exp(-(.01+w)/12),np.exp(-.01/12),12)
        assert abs(value-reference) < .00005
        checks.append(dict(check='Bao 2014 Table 4 Panel A monthly',w=w,n=12,h=1/12,
                     kappa=.01,value=value,published_four_decimals=reference,
                     absolute_error=abs(value-reference),passed=True))
    out=dict(seed=2026110681,calibration_replications_per_design=100000,
             checks=checks,all_passed=all(c['passed'] for c in checks),seconds=time.perf_counter()-start,
             source_sha256=hashlib.sha256(Path(__file__).with_name('bao_stationary.py').read_bytes()).hexdigest())
    Path(__file__).with_name('validation.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(all_passed=out['all_passed'],checks=len(checks),seconds=out['seconds'])))

if __name__=='__main__': main()
