# Frozen literature comparison protocol, 2026-11-06

Written before inspecting any independent-batch coverage outcomes. This is a
numerical implementation study, not a claim to reproduce the final published
2017 author software. Preserve this file and append amendments separately.

## Comparator and source boundary

Bao, Ullah and Wang's 2014 author working paper, pp. 4-7, equations (2.5)-(2.7),
provides the stationary unknown-mean distribution of the OLS slope and the
conditional distribution of the transformed speed given a positive fitted slope.
The 2017 journal full text is not available in this audit. We implement Gaussian
quadratic-form characteristic-function inversion for that stationary special
case and invert its two-sided 95% distribution test. This is an independent
implementation of the stationary distribution principle, not a reproduction of
the paper's fixed-start, plug-in-nuisance real-data interval. All slope estimates
<=0 are recorded as unavailable for the conditional-transformed-slope method.
Positive slopes >=1 remain eligible; a negative point speed does not itself
make a confidence set unavailable. Empty and unbounded confidence sets remain.

## Matching conditions and data

Compare on the exact same independently simulated paths as the new benchmark:
theta=1, mu=0, stationary variance=1, stationary Gaussian start, no measurement
noise; unknown mean and scale in inference; nominal level=.95. Include full
2000 outer trajectories in each of three new main batches, seeds 2026110601,
2026110602, 2026110603, at (r,a)=(2,.5),(2,.1),(10,.1), respectively n=4,20,100
transitions. These are three frozen design points spanning boundary risk and
the central design, not the complete 9-design main grid. Existing four methods
retain B=399. Data streams use the original run.py algorithm without alteration.
Compare methods by trajectory, never treating n/B/grid points as trajectories.
No noisy or fixed-start comparison is implied. Outer rows are taken in full,
not chosen by fitted slope, except where conditional denominators explicitly
require it. No seed replacement or optional outcome-driven simulation extension.

## Validation before outcome comparison

1. Match quadratic-form numerator/denominator to direct OLS for deterministic
   arrays, and verify invariance under additive location and multiplicative scale.
2. Check the known rank-two quadratic-form CDF against the Cauchy-ratio formula.
3. Check distribution quantiles against independently simulated stationary paths
   at n=4,20,100 and phi=exp(-.5),exp(-.1), using seed 2026110681 and 100000
   calibration paths, with a frozen 5-MC-SE screen. Validation paths are not
   comparison paths. Include positivity conditioning in the calculation.
4. Verify endpoint equations and report integration/root residuals; if validation
   fails, stop the affected comparator and report it rather than claim superiority.

## Numerical and failure rules

Use deterministic quadrature (absolute integration error target 1e-8), a full
phi-domain boundary calculation, and root tolerance 1e-8. Existence/monotonicity
screens are diagnostics, not a proof of universal connectedness. The numeric
algorithm must record numerical warnings, nonmonotonicity, failed roots and
unresolved boundaries rather than silently return a short interval. Add any
necessary implementation correction to AMENDMENTS.md before comparison execution.
Integration endpoints phi=0 and the phi->1 limit are retained to distinguish
infinite theta endpoints from arbitrary finite search truncation.

## Summaries and Monte Carlo precision

Per seed and pooled *within design*, report availability, numerical failures,
nonpositive slopes, empty sets, unbounded endpoints, conditional coverage, and
all-attempt valid-set-and-coverage; Wilson intervals and binomial MC SE for the
appropriate denominator. At p=.95, M=2000 gives SE=.00487, M=6000 gives SE=.00281;
worst-case SE is .01118 and .00645. This supports percentage-point comparisons,
not fine rankings. Finite nonempty width means and SE use a stated conditional
subset; any unbounded returned set makes its sample mean width infinite.
Paired differences use sd(per-path differences)/sqrt(number of common paths),
including joint hit differences on all attempts. Include common finite widths
and common-availability coverage contrasts. A shorter interval with deficient
coverage or substantial failure is not called superior. CIs are pointwise
Monte Carlo diagnostics, not multiplicity-adjusted superiority tests.

Runtime is elapsed per procedure on the same machine with a single numerical
thread; include preprocessing/validation separately, B and numerical tolerance,
Python/library versions, and whether the baseline timing was rerun or historical.
Compute cost comparisons are implementation dependent and not algorithmic lower
bounds. New design/B/simulation extensions require a separately dated amendment.
