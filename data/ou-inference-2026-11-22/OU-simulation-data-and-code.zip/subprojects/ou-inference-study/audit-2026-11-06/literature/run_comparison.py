"""Execute the frozen three-design, three-seed comparison on shared trajectories."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,platform,sys,time
import numpy as np
import scipy
from bao_stationary import confidence_set, conditional_speed_cdf, NumericalFailure

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT))
from src.ou_process import simulate_ou_exact
from src.ou_inference import OUFitError
from src.ou_uncertainty import ar_statistics, profile_theta_interval, wald_theta_interval, bootstrap_ou


def record_interval(interval):
    return dict(available=True,empty=interval.empty,lower=interval.lower,
                upper=interval.upper,width=interval.width,hit=interval.contains(1.),failure='')


def unavailable(reason):
    return dict(available=False,empty=None,lower=None,upper=None,width=None,hit=False,failure=reason)


def evaluate_distribution(observed_phi,n,dt,truth=1.):
    """Build a data-only set, then attach a simulation-only truth diagnostic."""
    if observed_phi <= 0:
        return unavailable('nonpositive slope: transformed estimator undefined')
    try:
        interval=confidence_set(observed_phi,n,dt)
    except (NumericalFailure,np.linalg.LinAlgError) as exc:
        return unavailable(type(exc).__name__+': '+str(exc))
    result=dict(available=True,empty=interval.empty,
        lower=min((lo for lo,hi in interval.intervals),default=0.),
        upper=max((hi for lo,hi in interval.intervals),default=0.),
        width=interval.width,hit=interval.contains(truth),failure='',
        components=interval.intervals,max_cdf_error=interval.max_cdf_error,
        max_endpoint_residual=interval.max_endpoint_residual,
        nonmonotonic_screen=interval.nonmonotonic,evaluations=interval.evaluations)
    # Neither disagreement nor diagnostic integration error changes availability.
    try:
        at_truth,error=conditional_speed_cdf(observed_phi,np.exp(-truth*dt),n)
        result.update(cdf_at_truth=at_truth,truth_cdf_error=error,
            truth_membership_agreement=(interval.contains(truth) == (.025 <= at_truth <= .975)),
            truth_diagnostic_only=True)
    except (NumericalFailure,np.linalg.LinAlgError) as exc:
        result.update(truth_membership_agreement=None,truth_diagnostic_error=str(exc),
                      truth_diagnostic_only=True)
    return result


def main():
    validation=json.loads((HERE/'validation.json').read_text())
    assert validation['all_passed']
    assert validation['source_sha256']==hashlib.sha256((HERE/'bao_stationary.py').read_bytes()).hexdigest(), 'Revalidate the comparator after source changes'
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HERE/'results',help='New empty results directory; existing raw runs are never overwritten')
    args=parser.parse_args()
    output=args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise SystemExit('Output directory is not empty; choose a fresh --output path to preserve previous evidence.')
    output.mkdir(parents=True,exist_ok=True)
    manifest=dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        seeds=[2026110601,2026110602,2026110603],replications=2000,bootstrap_replications=399,
        scenarios=[dict(r=2.,a=.5),dict(r=2.,a=.1),dict(r=10.,a=.1)],
        versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
        thread_environment={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')},
        hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
            [HERE/'PROTOCOL.md',HERE/'bao_stationary.py',HERE/'validation.json',Path(__file__)]})
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    beginning=time.perf_counter()
    for seed in manifest['seeds']:
        for r,a,group,scenario_index in [(2.,.5,0,2),(2.,.1,0,1),(10.,.1,1,4)]:
            name=f'seed{seed}_r{r:g}_a{a:g}'
            rng=np.random.default_rng(np.random.SeedSequence([seed,0,group]))
            initial=rng.standard_normal(2000)
            steps=int(round(r/.02))
            latent=simulate_ou_exact(1.,0.,np.sqrt(2.),0.,.02,steps,2000,rng)
            latent+=initial[:,None]*np.exp(-.02*np.arange(steps+1))
            training=latent[:,::int(round(a/.02))]
            tmp=output/(name+'.partial.jsonl')
            start=time.perf_counter()
            with tmp.open('w') as stream:
                for index,series in enumerate(training):
                    stats=ar_statistics(series)
                    row=dict(seed=seed,scenario=f'r={r:g},a={a:g},eta=0',replication=index,
                        r=r,a=a,n=stats.n,phi=stats.phi,methods={},timing={})
                    t=time.perf_counter()
                    row['methods']['profile']=record_interval(profile_theta_interval(series,a))
                    row['timing']['profile']=time.perf_counter()-t
                    t=time.perf_counter()
                    try:
                        row['methods']['wald']=record_interval(wald_theta_interval(series,a))
                    except OUFitError as exc:
                        row['methods']['wald']=unavailable(str(exc))
                    row['timing']['wald']=time.perf_counter()-t
                    t=time.perf_counter()
                    try:
                        b_rng=np.random.default_rng(np.random.SeedSequence([seed,2,scenario_index,index]))
                        boot=bootstrap_ou(series,a,b_rng,399,.95)
                        row['methods']['bootstrap_basic']=record_interval(boot['basic'])
                        row['methods']['bootstrap_profile']=record_interval(boot['calibrated_profile'])
                    except OUFitError as exc:
                        row['methods']['bootstrap_basic']=unavailable(str(exc))
                        row['methods']['bootstrap_profile']=unavailable(str(exc))
                    row['timing']['bootstrap_pair_shared']=time.perf_counter()-t
                    t=time.perf_counter()
                    row['methods']['stationary_distribution']=evaluate_distribution(stats.phi,stats.n,a)
                    row['timing']['stationary_distribution']=time.perf_counter()-t
                    stream.write(json.dumps(row,allow_nan=True)+'\n')
                    if (index+1)%500==0:
                        stream.flush()
                        print(f'{name}: {index+1}/2000, elapsed {time.perf_counter()-start:.1f}s',flush=True)
            data=tmp.read_bytes()
            with (output/(name+'.jsonl.gz')).open('wb') as raw:
                with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped: zipped.write(data)
            tmp.unlink()
    manifest['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    manifest['elapsed_seconds']=time.perf_counter()-beginning
    manifest['outputs']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.glob('*.jsonl.gz')}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(f'COMPLETE {manifest["elapsed_seconds"]:.1f}s',flush=True)

if __name__=='__main__': main()
