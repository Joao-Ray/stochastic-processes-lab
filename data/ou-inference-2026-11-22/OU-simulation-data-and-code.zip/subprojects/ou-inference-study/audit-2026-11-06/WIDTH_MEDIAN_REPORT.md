# Finite-width medians with distribution-free Monte Carlo intervals

This is a labelled post-audit analysis of every frozen record, not a new seed batch. It was added after the Wald width-moment issue was identified. [Plan](WALD_WIDTH_MOMENTS_PLAN.md) · [Mathematical argument](WALD_WIDTH_MOMENTS.md) · [All groups/contrasts](width_medians.json).

The interval estimates the conditional population median of finite nonempty returned-set lengths; it is not another drift confidence interval. It does not assume a finite mean or variance. Available/empty/infinite counts remain visible. Unavailable and infinite outcomes are not made into a shorter interval. Single batches and all six baseline method-pair contrasts are in JSON. Each pooled scenario has 6000 independent trajectories; scenarios sharing paths are never pooled together.

| Group | Scenario | Method | Available / attempts | Empty / infinite | Finite n | Median length [pointwise 95% order-stat CI] |
|---|---|---|---:|---:|---:|---|
| new-pooled-main | r=2,a=0.02,eta=0 | wald | 5937/6000 | 0/0 | 5937 | 6.4037 [6.3019, 6.5067] |
| new-pooled-main | r=2,a=0.02,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 6.5129 [6.4102, 6.6063] |
| new-pooled-main | r=2,a=0.02,eta=0 | bootstrap_basic | 5937/6000 | 0/0 | 5937 | 4.5678 [4.4752, 4.6596] |
| new-pooled-main | r=2,a=0.02,eta=0 | bootstrap_profile | 5937/6000 | 0/0 | 5937 | 7.3118 [7.2155, 7.4039] |
| new-pooled-main | r=2,a=0.1,eta=0 | wald | 5878/6000 | 0/0 | 5878 | 7.1830 [7.0473, 7.3061] |
| new-pooled-main | r=2,a=0.1,eta=0 | profile | 6000/6000 | 0/468 | 5532 | 7.9635 [7.7977, 8.1270] |
| new-pooled-main | r=2,a=0.1,eta=0 | bootstrap_basic | 5878/6000 | 0/172 | 5706 | 5.1488 [5.0626, 5.2806] |
| new-pooled-main | r=2,a=0.1,eta=0 | bootstrap_profile | 5878/6000 | 0/518 | 5360 | 9.5702 [9.3629, 9.7596] |
| new-pooled-main | r=2,a=0.5,eta=0 | wald | 2713/6000 | 0/0 | 2713 | 6.8047 [6.5180, 7.1543] |
| new-pooled-main | r=2,a=0.5,eta=0 | profile | 6000/6000 | 0/5551 | 449 | 2.6724 [2.4356, 2.8893] |
| new-pooled-main | r=2,a=0.5,eta=0 | bootstrap_basic | 2713/6000 | 0/2204 | 509 | 3.2298 [3.0001, 3.5345] |
| new-pooled-main | r=2,a=0.5,eta=0 | bootstrap_profile | 2713/6000 | 0/2651 | 62 | 3.5932 [2.5474, 4.2289] |
| new-pooled-main | r=10,a=0.02,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 2.0389 [2.0251, 2.0496] |
| new-pooled-main | r=10,a=0.02,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 2.0432 [2.0295, 2.0539] |
| new-pooled-main | r=10,a=0.02,eta=0 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 1.8692 [1.8439, 1.8902] |
| new-pooled-main | r=10,a=0.02,eta=0 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 2.2591 [2.2433, 2.2734] |
| new-pooled-main | r=10,a=0.1,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 2.1587 [2.1425, 2.1744] |
| new-pooled-main | r=10,a=0.1,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 2.1900 [2.1732, 2.2048] |
| new-pooled-main | r=10,a=0.1,eta=0 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 1.9341 [1.9110, 1.9585] |
| new-pooled-main | r=10,a=0.1,eta=0 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 2.4187 [2.4002, 2.4362] |
| new-pooled-main | r=10,a=0.5,eta=0 | wald | 5870/6000 | 0/0 | 5870 | 2.8793 [2.8335, 2.9310] |
| new-pooled-main | r=10,a=0.5,eta=0 | profile | 6000/6000 | 0/2125 | 3875 | 3.0549 [3.0034, 3.1225] |
| new-pooled-main | r=10,a=0.5,eta=0 | bootstrap_basic | 5870/6000 | 0/954 | 4916 | 2.2164 [2.1746, 2.2638] |
| new-pooled-main | r=10,a=0.5,eta=0 | bootstrap_profile | 5870/6000 | 0/2290 | 3580 | 3.4372 [3.3837, 3.4962] |
| new-pooled-main | r=10,a=0.1,eta=0.2 | wald | 6000/6000 | 0/0 | 6000 | 2.6138 [2.5915, 2.6336] |
| new-pooled-main | r=10,a=0.1,eta=0.2 | profile | 6000/6000 | 0/0 | 6000 | 2.6545 [2.6316, 2.6749] |
| new-pooled-main | r=10,a=0.1,eta=0.2 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 2.6102 [2.5760, 2.6398] |
| new-pooled-main | r=10,a=0.1,eta=0.2 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 2.8609 [2.8432, 2.8833] |
| new-pooled-main | r=10,a=0.1,eta=0.5 | wald | 6000/6000 | 0/0 | 6000 | 4.4588 [4.4170, 4.5107] |
| new-pooled-main | r=10,a=0.1,eta=0.5 | profile | 6000/6000 | 0/2 | 5998 | 4.5799 [4.5356, 4.6343] |
| new-pooled-main | r=10,a=0.1,eta=0.5 | bootstrap_basic | 6000/6000 | 0/1 | 5999 | 4.3687 [4.3298, 4.4092] |
| new-pooled-main | r=10,a=0.1,eta=0.5 | bootstrap_profile | 6000/6000 | 0/1 | 5999 | 4.7301 [4.6816, 4.7727] |
| new-pooled-main | r=30,a=0.02,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 1.0785 [1.0738, 1.0833] |
| new-pooled-main | r=30,a=0.02,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 1.0792 [1.0746, 1.0840] |
| new-pooled-main | r=30,a=0.02,eta=0 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 1.1707 [1.1665, 1.1753] |
| new-pooled-main | r=30,a=0.02,eta=0 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 1.1305 [1.1254, 1.1361] |
| new-pooled-main | r=30,a=0.1,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 1.1280 [1.1234, 1.1335] |
| new-pooled-main | r=30,a=0.1,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 1.1329 [1.1282, 1.1384] |
| new-pooled-main | r=30,a=0.1,eta=0 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 1.1907 [1.1859, 1.1958] |
| new-pooled-main | r=30,a=0.1,eta=0 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 1.1851 [1.1803, 1.1915] |
| new-pooled-main | r=30,a=0.5,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 1.4728 [1.4599, 1.4824] |
| new-pooled-main | r=30,a=0.5,eta=0 | profile | 6000/6000 | 0/37 | 5963 | 1.5691 [1.5529, 1.5809] |
| new-pooled-main | r=30,a=0.5,eta=0 | bootstrap_basic | 6000/6000 | 0/10 | 5990 | 1.4009 [1.3916, 1.4117] |
| new-pooled-main | r=30,a=0.5,eta=0 | bootstrap_profile | 6000/6000 | 0/36 | 5964 | 1.6319 [1.6186, 1.6484] |
| new-pooled-confirmation | r=10,a=0.1,eta=0 | wald | 6000/6000 | 0/0 | 6000 | 2.1884 [2.1728, 2.2085] |
| new-pooled-confirmation | r=10,a=0.1,eta=0 | profile | 6000/6000 | 0/0 | 6000 | 2.2189 [2.2033, 2.2396] |
| new-pooled-confirmation | r=10,a=0.1,eta=0 | bootstrap_basic | 6000/6000 | 0/0 | 6000 | 1.9825 [1.9554, 2.0159] |
| new-pooled-confirmation | r=10,a=0.1,eta=0 | bootstrap_profile | 6000/6000 | 0/0 | 6000 | 2.4577 [2.4372, 2.4746] |
| literature-pooled | r=10,a=0.1,eta=0 | stationary_distribution | 6000/6000 | 0/0 | 6000 | 2.2143 [2.1885, 2.2424] |
| literature-pooled | r=2,a=0.1,eta=0 | stationary_distribution | 5981/6000 | 53/533 | 5395 | 6.4045 [6.2765, 6.5369] |
| literature-pooled | r=2,a=0.5,eta=0 | stationary_distribution | 3101/6000 | 128/2952 | 21 | 1.1848 [0.6102, 1.6796] |

## Paired distribution-inversion minus baseline length differences

These are medians of individual matched differences on the common finite nonempty subset, rather than differences of medians. A negative value represents shorter distribution-inversion lengths on that subset. This does not cancel failure or unbounded-set probabilities.

| Scenario | Baseline | Common finite n | Median paired difference [pointwise 95% order-stat CI] |
|---|---|---:|---|
| r=10,a=0.1,eta=0 | wald | 6000 | 0.0527 [0.0436, 0.0623] |
| r=10,a=0.1,eta=0 | profile | 6000 | 0.0212 [0.0099, 0.0294] |
| r=10,a=0.1,eta=0 | bootstrap_basic | 6000 | 0.2466 [0.2447, 0.2492] |
| r=10,a=0.1,eta=0 | bootstrap_profile | 6000 | -0.2316 [-0.2412, -0.2226] |
| r=2,a=0.1,eta=0 | wald | 5342 | -0.1548 [-0.1888, -0.1291] |
| r=2,a=0.1,eta=0 | profile | 5381 | -1.4631 [-1.4943, -1.4352] |
| r=2,a=0.1,eta=0 | bootstrap_basic | 5342 | 1.5544 [1.5191, 1.6013] |
| r=2,a=0.1,eta=0 | bootstrap_profile | 5293 | -2.9781 [-3.0356, -2.9245] |
| r=2,a=0.5,eta=0 | wald | 0 | undefined |
| r=2,a=0.5,eta=0 | profile | 11 | -1.8114 [-3.4620, -1.0340] |
| r=2,a=0.5,eta=0 | bootstrap_basic | 0 | undefined |
| r=2,a=0.5,eta=0 | bootstrap_profile | 0 | undefined |

For sorted observations w_(1),...,w_(N), use k=binomial_quantile((1-.95)/2,N,.5) and [w_(k),w_(N-k+1)]. If k=0 the interval is unbounded. For a continuous median its coverage is 1-2*P(Binomial(N,.5)<k)>=.95; ties are conservative. Independent outer sampling is required; inner bootstrap replicates never count as N. All intervals are pointwise, not simultaneous comparison guarantees.
