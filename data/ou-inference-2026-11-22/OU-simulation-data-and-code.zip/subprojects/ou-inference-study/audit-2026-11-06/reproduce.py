"""Full-scale replay into a fresh output directory; never overwrites audit evidence."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
A=Path(__file__).resolve().parent;ROOT=A.parents[2];S=A.parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--scope',choices=['new-seeds','original','supplements','all'],default='all');args=parser.parse_args()
if args.output.exists() and any(args.output.iterdir()):raise SystemExit('Use a new/empty output directory; preserved evidence is never replaced.')
args.output.mkdir(parents=True,exist_ok=True)
protocol=json.loads((A/'PROTOCOL.json').read_text());jobs=[]
if args.scope in ['new-seeds','all']:
 for r in protocol['runs']:
  config=ROOT/r['config'];assert hashlib.sha256(config.read_bytes()).hexdigest()==r['config_sha256']
  jobs.append((S/'run.py',config,f"new-batch{r['batch']}-{r['design']}",config.parent/'replications.csv.gz'))
if args.scope in ['original','all']:
 for label,config in [('main','config.json'),('confirmation','confirmation.json')]:jobs.append((S/'run.py',S/config,'original-'+label,S/'results'/label/'replications.csv.gz'))
if args.scope in ['supplements','all']:
 for supplement in ['finite-sample','measurement-error']:
  for label,config in [('main','config.json'),('confirmation','confirmation.json')]:jobs.append((S/supplement/'run.py',S/supplement/config,supplement+'-'+label,S/supplement/'results'/label/'replications.csv.gz'))
results=[]
for script,config,name,reference in jobs:
 out=args.output/name;out.mkdir()
 cmd=[sys.executable,str(script),'--config',str(config),'--output',str(out)]
 before=time.perf_counter()
 with (out/'execution.log').open('w') as log:
  status=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'MPLCONFIGDIR':str(args.output/'mpl-cache'),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'})
 entry={'name':name,'command':cmd,'exit_code':status.returncode,'seconds':time.perf_counter()-before}
 if status.returncode==0:
  entry['sha256']=hashlib.sha256((out/'replications.csv.gz').read_bytes()).hexdigest();entry['same_archived_bytes']=(out/'replications.csv.gz').read_bytes()==reference.read_bytes()
 results.append(entry);(args.output/'reproduction.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,entry,flush=True)
 if status.returncode:raise SystemExit(status.returncode)
