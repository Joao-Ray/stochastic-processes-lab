"""Account for every outer attempt; never pair different duration groups."""
from pathlib import Path
import collections,csv,gzip,hashlib,importlib.util,json,math,os,re
import numpy as np
from scipy.stats import norm
ROOT=Path(__file__).resolve().parents[3]; A=Path(__file__).resolve().parent; S=ROOT/'subprojects/ou-inference-study'
spec=importlib.util.spec_from_file_location('ou_study',S/'run.py'); study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def read_rows(p,batch):
    with gzip.open(p,'rt') as f:raw=list(csv.DictReader(f))
    rows=[]
    for rr in raw:
        row={}
        for k,v in rr.items():
            if k in ('scenario','failure','correction_failure'): row[k]=v
            elif v in ('True','False'):row[k]=v=='True'
            elif not v:row[k]=None
            else:row[k]=float(v)
        row['replication']=int(row['replication']);row['batch']=batch
        rows.append(row)
    return rows

def mean_se(values):
    v=np.asarray(values,float);n=len(v)
    if not n:return {'n':0,'mean':None,'mc_se':None,'mc_95':None}
    m=float(v.mean());se=float(v.std(ddof=1)/np.sqrt(n)) if n>1 else None
    return {'n':n,'mean':m,'mc_se':se,'mc_95':[m-1.96*se,m+1.96*se] if se is not None else None}

def pairs(rows):
    out={}
    for i,x in enumerate(study.METHODS):
        for y in study.METHODS[i+1:]:
            common=[r for r in rows if r[x+'_available'] and r[y+'_available']]
            widths=[r for r in common if not r[x+'_empty'] and not r[y+'_empty'] and np.isfinite(r[x+'_upper']) and np.isfinite(r[y+'_upper'])]
            out[x+' minus '+y]={'joint_coverage':mean_se([int(r[x+'_hit'])-int(r[y+'_hit']) for r in rows]),'common_available_coverage':mean_se([int(r[x+'_hit'])-int(r[y+'_hit']) for r in common]),'common_finite_nonempty_width':mean_se([(r[x+'_upper']-r[x+'_lower'])-(r[y+'_upper']-r[y+'_lower']) for r in widths])}
    return out

def validate_rows(rows, truth=1.):
    """Reject corrupted accounting instead of interpreting NaN/missing as infinity."""
    for r in rows:
        for name in study.METHODS:
            available=r[name+'_available'];hit=r[name+'_hit'];empty=r[name+'_empty']
            lo,hi=r[name+'_lower'],r[name+'_upper']
            if not isinstance(available,bool) or not isinstance(hit,bool):
                raise ValueError('availability and hit must be boolean')
            if not available:
                if hit or lo is not None or hi is not None or empty is not None:
                    raise ValueError('unavailable procedure must not have endpoints or a hit')
                continue
            if not isinstance(empty,bool) or lo is None or hi is None:
                raise ValueError('available set must have an empty flag and endpoints')
            if not np.isfinite(lo) or lo<0 or np.isnan(hi) or hi<lo:
                raise ValueError('invalid numeric endpoints; only positive upper infinity is allowed')
            if empty and (lo!=0 or hi!=0):
                raise ValueError('empty set must use the original (0,0) representation')
            expected=not empty and lo<=truth<=hi
            if hit!=expected:
                raise ValueError('hit disagrees with set membership')
        if not np.isfinite(r['phi']):raise ValueError('nonfinite slope')
        for name in ('theta','corrected_theta'):
            if r[name] is not None and (not np.isfinite(r[name]) or r[name]<=0):
                raise ValueError('invalid reported positive OU estimate')

def detailed(rows,scenario):
    validate_rows(rows)
    out=study.summarize(rows,scenario,1.)
    out['outer_failure_reasons']=dict(collections.Counter(r['failure'] for r in rows if r['failure']))
    out['correction_failure_reasons']=dict(collections.Counter(r['correction_failure'] for r in rows if r['correction_failure']))
    out['slope_le_zero']=sum(r['phi']<=0 for r in rows)
    out['slope_ge_one']=sum(r['phi']>=1 for r in rows)
    out['all_method_paired_comparisons']=pairs(rows)
    for method,entry in out['methods'].items():
        entry['finite_width_uncertainty_interpretation']='descriptive sample s/sqrt(n); finite population moments not certified; see WIDTH_MEDIAN_REPORT.md'
        if method=='wald':entry['finite_population_mean_length_in_ideal_gaussian_model']=False
        available=[r for r in rows if r[method+'_available']]
        entry['failure_rate']=study.coverage([not r[method+'_available'] for r in rows])
        entry['empty_rate_all_attempts']=study.coverage([bool(r[method+'_empty']) for r in rows])
        entry['unbounded_rate_all_attempts']=study.coverage([bool(r[method+'_available']) and math.isinf(r[method+'_upper']) for r in rows])
        entry['zero_lower_bound']=sum(r[method+'_lower']==0 and not r[method+'_empty'] for r in available)
        entry['invalid_numeric_endpoints']=sum(math.isnan(r[method+'_lower']) or math.isnan(r[method+'_upper']) or r[method+'_lower']<0 or r[method+'_upper']<r[method+'_lower'] for r in available)
    for contrast in out['all_method_paired_comparisons'].values():
        contrast['common_finite_nonempty_width']['mc_interval_interpretation']='descriptive mean +/-1.96 sample SE; moment assumptions not certified; use median order-statistic interval for moment-free uncertainty'
    return out

def clean_json(value):
    if isinstance(value,dict):return {k:clean_json(v) for k,v in value.items()}
    if isinstance(value,list):return [clean_json(v) for v in value]
    if isinstance(value,np.generic):return value.item()
    return value

def compare_replay():
    output={}
    for name in ['main','confirmation']:
        old=S/'results'/name;new=A/'original-replay'/name
        x=json.loads((old/'summary.json').read_text());y=json.loads((new/'summary.json').read_text())
        scientific=['config','scenarios','paired_sampling_comparisons','data_source','seed_scheme','bootstrap_initialization']
        output[name]={'archive_hash_valid':sha(old/'replications.csv.gz')==x['record_archive_sha256'],'compressed_bytes_identical':(old/'replications.csv.gz').read_bytes()==(new/'replications.csv.gz').read_bytes(),'uncompressed_csv_identical':gzip.decompress((old/'replications.csv.gz').read_bytes())==gzip.decompress((new/'replications.csv.gz').read_bytes()),'scientific_fields_identical':{k:x[k]==y[k] for k in scientific},'old_versions':x['versions'],'new_versions':y['versions'],'non_scientific_changes':[k for k in set(x)|set(y) if k not in scientific and x.get(k)!=y.get(k)]}
    return output

def paired_grid_contrasts(rows):
    """Within-duration, within-batch contrasts on shared latent trajectories."""
    grids=[]
    for r in [2.,10.,30.]:
        fine={(x['batch'],x['replication']):x for x in rows if x['scenario']==f'r={r:g},a=0.02,eta=0'}
        for a in [.1,.5]:
            coarse={(x['batch'],x['replication']):x for x in rows if x['scenario']==f'r={r:g},a={a:g},eta=0'}
            assert fine.keys()==coarse.keys()
            common=[(f,coarse[k]) for k,f in fine.items() if f['theta'] is not None and coarse[k]['theta'] is not None]
            grids.append({'duration':r,'fine_a':.02,'coarse_a':a,'unit':'same latent path within batch and duration','common_valid_MSE_fine_minus_coarse':mean_se([(f['theta']-1)**2-(c['theta']-1)**2 for f,c in common]),'joint_bootstrap_profile_coverage_fine_minus_coarse':mean_se([int(f['bootstrap_profile_hit'])-int(coarse[k]['bootstrap_profile_hit']) for k,f in fine.items()])})
    return grids


def independent_duration_contrasts(rows):
    """Duration groups are independent even when repetition labels match."""
    independent=[]
    for a in [.02,.1,.5]:
        for r1,r2 in [(2.,10.),(10.,30.)]:
            x=np.array([(rr['theta']-1)**2 for rr in rows if rr['scenario']==f'r={r1:g},a={a:g},eta=0' and rr['theta'] is not None]);y=np.array([(rr['theta']-1)**2 for rr in rows if rr['scenario']==f'r={r2:g},a={a:g},eta=0' and rr['theta'] is not None])
            d=float(x.mean()-y.mean());se=float(np.sqrt(x.var(ddof=1)/len(x)+y.var(ddof=1)/len(y)))
            independent.append({'a':a,'first_r':r1,'second_r':r2,'n_first':len(x),'n_second':len(y),'MSE_first_minus_second':d,'mc_se':se,'mc_95':[d-1.96*se,d+1.96*se],'caution':'Different conditional-admissibility populations; independent, not paired; no unconditional risk claim'})
    return independent


def main():
    protocol=json.loads((A/'PROTOCOL.json').read_text());assert sha(A/'PROTOCOL.json')==(A/'PROTOCOL.sha256').read_text().split()[0]
    output={'protocol_sha256':sha(A/'PROTOCOL.json'),'batches':{},'pooled':{},'stability':{},'paired_grids':{},'independent_duration_contrasts':{},'old_vs_new':{},'replay':compare_replay()}
    all_rows={name:[] for name in ['main','confirmation']};scenario_meta={}
    for run in protocol['runs']:
        folder=(ROOT/run['config']).parent
        st=json.loads((folder/'execution.json').read_text());assert st['returncode']==0
        assert sha(ROOT/run['config'])==run['config_sha256']==st['config_sha256']
        assert st['protocol_sha256']==sha(A/'PROTOCOL.json')
        for path,expected in st['algorithm_sha256'].items():
            assert sha(ROOT/path)==expected, f'Algorithm changed: {path}'
        sm=json.loads((folder/'summary.json').read_text());assert sha(folder/'replications.csv.gz')==sm['record_archive_sha256']==st['record_sha256']
        rows=read_rows(folder/'replications.csv.gz',run['batch']);assert len(rows)==2000*len(sm['scenarios'])
        all_rows[run['design']]+=rows
        entries={}
        for sc in sm['scenarios']:
            meta={k:sc[k] for k in ['id','r','a','noise_sd','duration','dt','n_transitions','pseudo_theta']}
            scenario_meta[sc['id']]=meta
            subset=[r for r in rows if r['scenario']==sc['id']]
            assert len(subset)==len({r['replication'] for r in subset})==2000
            entries[sc['id']]=detailed(subset,meta)
        output['batches'][f"batch{run['batch']}-{run['design']}"]=entries
        # Repair location-dependent inherited report links; scientific records are untouched.
        rp=folder/'report.md';txt=rp.read_text()
        for target in ['PROTOCOL.md','THEORY.md']:
            txt=re.sub(r'\((?:\.\./)+'+re.escape(target)+r'\)', '('+os.path.relpath(S/target,folder)+')',txt)
        rp.write_text(txt)
    for design,rows in all_rows.items():
        out=output['pooled'][design]={}
        ids=sorted({r['scenario'] for r in rows})
        for sid in ids:
            subset=[r for r in rows if r['scenario']==sid];assert len(subset)==6000
            out[sid]=detailed(subset,scenario_meta[sid])
        output['paired_grids'][design]=paired_grid_contrasts(rows) if design=='main' else []
        output['independent_duration_contrasts'][design]=independent_duration_contrasts(rows) if design=='main' else []
        stable={}
        old=json.loads((S/'results'/design/'summary.json').read_text());old_by={s['id']:s for s in old['scenarios']}
        changes={}
        for sid,sc in out.items():
            bs=[output['batches'][f'batch{b}-{design}'][sid] for b in [1,2,3]]
            d=sc['joint_bootstrap_minus_profile'];ci=[d['difference']-1.96*d['mc_se'],d['difference']+1.96*d['mc_se']]
            vals=[b['joint_bootstrap_minus_profile']['difference'] for b in bs]
            same=all(v>0 for v in vals) or all(v<0 for v in vals)
            stable[sid]={'batch_joint_differences':vals,'pooled_difference':d,'pooled_pointwise_95':ci,'stable_direction':same and (ci[0]>0 or ci[1]<0),'interpretation':'pointwise descriptive screen, not familywise superiority or equivalence'}
            changes[sid]={}
            for m in study.METHODS:
                oldm=old_by[sid]['methods'][m]['success_and_coverage'];newm=sc['methods'][m]['success_and_coverage'];delta=newm['coverage']-oldm['coverage'];se=math.hypot(newm['mc_se'],oldm['mc_se'])
                changes[sid][m]={'new_minus_old_joint':delta,'independent_mc_se':se,'pointwise_95':[delta-1.96*se,delta+1.96*se],'pointwise_discrepancy':abs(delta)>1.96*se,'multiplicity':'descriptive; many dependent comparisons; no discovery claim'}
        output['stability'][design]=stable;output['old_vs_new'][design]=changes
    output['total_records']=sum(map(len,all_rows.values()))
    output['total_bootstrap_regressions']=sum(int(r['bootstrap_count']) for rows in all_rows.values() for r in rows)
    output['width_uncertainty_policy']={'wald_population_mean':'infinite conditional interior-fit length under ideal nondegenerate Gaussian law, finite n>=4','sample_width_mc_se':'descriptive s/sqrt(n); no finite-population-mean MCSE guarantee','alternative':'WIDTH_MEDIAN_REPORT.md: conditional median order-statistic intervals need no moment assumption','coverage_indicators':'bounded; existing coverage uncertainty unchanged'}
    (A/'robustness'/'analysis.json').write_text(json.dumps(clean_json(output),indent=2,allow_nan=False)+'\n')
    write_report(output)
    print(json.dumps({'total_records':output['total_records'],'inner_regressions':output['total_bootstrap_regressions'],'replay':output['replay']},indent=2))

def write_report(o):
    f=lambda x:'NA' if x is None else f'{x:.5f}'
    lines=['# Independent-seed robustness and original-seed replay','', 'Frozen protocol: [PROTOCOL.json](../PROTOCOL.json), with its SHA256 captured before simulations. Internal timestamping is not external preregistration.', '', 'Three independent batches repeat the entire main design (11 scenarios, M=2000 each, B=399) and central confirmation (M=2000, B=999). Pooling is within design/scenario across the three new batches only: M=6000. Original data are not pooled. No seed, scenario or failed result was replaced.', '', f"New scenario records: **{o['total_records']:,}**; inner bootstrap regressions: **{o['total_bootstrap_regressions']:,}**. These are not all independent trajectories: main batches contain 3 duration pools each, with shared grids and noise scenarios. There are 18,000 new independent main latent trajectories plus 6,000 separate confirmation trajectories.", '', 'All Monte Carlo intervals below are pointwise. Conditional coverage denominator includes returned empty sets; unavailable sets contribute only to all-attempt joint success. Infinite endpoints are valid reported sets, with infinite sample mean width; finite widths exclude them explicitly. Point-estimate bias and RMSE are conditional on valid estimates. Paired width differences further condition on both sets finite and nonempty.', '', '## Full coverage and width results', '', '| Run | Scenario | Method | Available / attempts | Conditional coverage (MC SE) | Joint coverage (MC SE) | Empty | Infinite upper | Finite nonempty n | Finite sample mean width (descriptive s/sqrt(n)) |', '|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
    datasets=[*o['batches'].items(),*((f'pooled-{k}',v) for k,v in o['pooled'].items())]
    for label,scenarios in datasets:
        for sid,s in scenarios.items():
            for name,m in s['methods'].items():
                c,j=m['conditional'],m['success_and_coverage']
                lines.append(f"| {label} | {sid} | {name} | {m['available']}/{m['attempted']} | {f(c['coverage'])} ({f(c['mc_se'])}) | {f(j['coverage'])} ({f(j['mc_se'])}) | {m['empty']} | {m['unbounded_upper']} | {m['finite_nonempty_width_n']} | {f(m['finite_nonempty_mean_width'])} ({f(m['finite_nonempty_width_mc_se'])}) |")
    lines+=['','Width uncertainty caveat: Wald lengths have an infinite conditional population mean in the ideal finite-sample Gaussian model despite finite individual endpoints. Their s/sqrt(n) is descriptive, not a valid population-mean MCSE. See [width-moment argument](../WALD_WIDTH_MOMENTS.md). Other common-finite width errors require their own moment conditions. Coverage/availability indicators are bounded and unaffected.','','## Point estimates and failures','','| Run | Scenario | MLE valid n | MLE bias (MC SE) | MLE RMSE (MC SE) | Corrected valid n | Corrected bias (MC SE) | Corrected RMSE (MC SE) | Common n | Paired corrected-minus-MLE MSE (MC SE) |','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for label,scenarios in datasets:
        for sid,s in scenarios.items():
            m,c,p=s['mle'],s['corrected'],s['paired_correction_minus_mle_mse']
            lines.append(f"| {label} | {sid} | {m['n']} | {f(m['bias'])} ({f(m['bias_mc_se'])}) | {f(m['rmse'])} ({f(m['rmse_mc_se'])}) | {c['n']} | {f(c['bias'])} ({f(c['bias_mc_se'])}) | {f(c['rmse'])} ({f(c['rmse_mc_se'])}) | {p['n']} | {f(p['difference'])} ({f(p['mc_se'])}) |")
    lines+=['','Every outer failure remains in the gzip records. `analysis.json` provides failure reason counts, slope<=0 and slope>=1, correction failures, failure-rate Wilson intervals, empty/unbounded rates, all six paired method comparisons, and common-finite width differences. No unexpected numerical endpoint failures are silently deleted.','','## Stability of bootstrap-profile minus profile joint coverage','','| Design/scenario | Batch 1 | Batch 2 | Batch 3 | Pooled difference (MC SE) | Pointwise interval | Stable direction screen |','|---|---:|---:|---:|---:|---|---|']
    for design,scenarios in o['stability'].items():
        for sid,x in scenarios.items():
            d=x['pooled_difference'];vs=x['batch_joint_differences']
            lines.append(f"| {design}: {sid} | {f(vs[0])} | {f(vs[1])} | {f(vs[2])} | {f(d['difference'])} ({f(d['mc_se'])}) | {x['pooled_pointwise_95']} | {x['stable_direction']} |")
    lines+=['','This screen does not select a winner: a higher joint rate can coexist with undercoverage and infinite widths. Mixed signs or an interval containing zero do not establish equivalence. Main vs confirmation changes both B and seed.','','## Sampling-grid and duration comparisons','','Paired nested-grid contrasts use `(batch, duration, replication)` identities. Independent-duration contrasts use the sum of the two sample-mean variances. Exact values and denominators are in `paired_grids` and `independent_duration_contrasts` in [analysis.json](analysis.json); no records from different duration pools are treated as paired.','','## Historical replay evidence','']
    for design,x in o['replay'].items():lines.append(f"- {design}: original archive SHA valid={x['archive_hash_valid']}; compressed identical={x['compressed_bytes_identical']}; decoded CSV identical={x['uncompressed_csv_identical']}; scientific fields={x['scientific_fields_identical']}. Non-scientific metadata changes: {x['non_scientific_changes']}.")
    lines+=['','Full original-replay execution logs are under `../original-replay/{main,confirmation}`. Hash equality checks consistency and replay; it does not establish the truth of the statistical assumptions. Old-vs-new differences are in `old_vs_new`, with independent MC SE; the many pointwise comparisons are not multiplicity-adjusted discoveries.','','## Reproduce','','Run `python subprojects/ou-inference-study/audit-2026-11-06/run_robustness.py`, then this analysis script. Existing successful runs are verified instead of overwritten. To execute from scratch use a clean output copy with the frozen protocol/configs, without execution files. No reduced run is labelled a full replay.','']
    (A/'robustness'/'REPORT.md').write_text('\n'.join(lines))

if __name__=='__main__':main()
