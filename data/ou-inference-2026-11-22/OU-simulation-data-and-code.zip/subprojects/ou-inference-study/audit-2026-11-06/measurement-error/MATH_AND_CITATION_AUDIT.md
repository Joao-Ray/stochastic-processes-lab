# 含测量误差补充研究：数学、引用与适用范围核查

核查日期：2026-11-06。这里记录人工可追溯的代数核查和已执行计算验证，
不替代领域专家审稿。代码行号对应运行前源码快照（仓库起点 e2db71b），
具体快照哈希见 main/start.json 和 confirmation/start.json。

## 主张—数学—代码对应

| 正文主张 | 公式或推导 | 必要条件 | 来源及定位 | 实现定位 | 核查状态 |
| --- | --- | --- | --- | --- | --- |
| 潜在 OU 可精确离散为平稳 AR(1) | phi=exp(-theta Delta)，创新方差 V(1-phi²) | theta,V>0；stationary 初值；没有 Euler 近似 | 本仓库 OU 推导；含噪模型见 Chen et al. (2000), p142 Eq1.3 | measurement-error/run.py:65–77，src/ou_monte_carlo.py:stationary_null_paths | 代码和参数映射已核查；fixed5 明确是反例设计 |
| 含独立测量噪声观测不是 AR(1) | Cov(U_i,U_(i-1))=-phi eta² | 相互独立、与潜在过程独立的 Gaussian sensor noise | [Holý & Tomanová, §2.3, Eq19–28](https://arxiv.org/html/1811.09312) | src/ou_measurement_error.py:46–83 使用完整协方差似然 | 原文对应公式已核验；不把 noisy pairwise conditional law 当 full likelihood |
| site means 与 contrasts 独立 | barY covariance=s²A，W/eta²~chi²[m(k-1)] | 同时重复共享一个 latent state；传感器误差 iid Gaussian；k>1 时 eta²>0 | [本地推导 §2](../../measurement-error/THEORY.md#2-exact-reduction-for-repeated-readings)，正交变换与 Gaussian independence | src/ou_measurement_error.py:29–43,46–83；test_profile_against_dense_gaussian_and_contrasts | 推导复核；独立 dense/contrast 数值测试通过；重复读数不是独立轨迹 |
| ML/REML 分别 profile 掉未知 mu 与 scale | nu=N 或 N-1；REML 加 log(1ᵀA⁻¹1)/2 | mu、V、eta² 均未知；stationary joint likelihood；可识别的内部参数区间 | 本地推导 §2；[Patterson & Thompson 1971](https://doi.org/10.1093/biomet/58.3.545) 为 REML 归属来源 | src/ou_measurement_error.py:67–83 | 公式与 dense Gaussian、Kalman、正交残差参考一致；P&T 本次未完成全文核验，不能宣称原文每条公式已核验 |
| 三对角形式精确计算 likelihood | Q=qR⁻¹，H=gamma qI+(1-gamma)Q/k，A⁻¹=H⁻¹Q，log|A|=log|H|-log q | 0<=phi<1；协方差正定；重复设计排除 eta²=0 奇异边界 | 本地推导 §3（det R=q^(m-1)） | src/ou_measurement_error.py:54–77 | 代数已复核；独立 dense/Kalman 测试通过；线性时间评价不等于全局优化证明 |
| ML/REML profile 有 95% coverage | 真值处 2(nll_null-nll_fit)<=chi²_1(.95) | 渐近正则条件；不是固定短窗口或边界保证 | 本地 protocol 与 src docstring 明确渐近性质 | src/ou_measurement_error.py:195–206；run.py:114–145 | **不能作有限样本保证**；仅计算真值处成员检验，没有返回完整区间、端点、长度 |
| drift 有限点估计可用 | converged && !white && !cap | 搜索 theta Delta in [1e-5,20]，含 phi=0 极限；非全局证书 | 本地 protocol，固定优化算法 | src/ou_measurement_error.py:116–192 | 白噪声、边界、未收敛不能伪装有限点估计；失败均进入分母；成员检验与点估计可用性不同 |
| 不同设计/时长可配对 | 不成立；scenario_index 是独立流键 | 每次完整轨迹为一个独立外层单位 | run.py 中 SeedSequence([seed,300,index,role]) | run.py:65–77；scripts/compare_noise_designs.py:contrast | 不同 T 或 k 均独立；只允许同记录上的方法比较配对；未发现跨设计虚假配对 |
| 重复读数可提高局部信息 | I_ab=tr(C⁻¹C_aC⁻¹C_b)/2+1_(a=b=eta²)d/(2eta⁴)；消 nuisance 得 Schur complement | 内部正则参数、Gaussian law、局部无偏 CR 框架 | 本地推导 §4；Gaussian covariance score 恒等式 | src/ou_measurement_error.py:209–228；独立 full-covariance derivative test | 推导和独立数值参考一致；不能推出所有有偏估计量 RMSE 下界或 k>1 普遍获益 |
| 弱信号使 drift 难以分辨 | Gaussian KL，Pinsker，two-point testing，coverage event transfer | 固定有限 m；同总方差/均值；两 drift 对应不同 diffusion 以固定 V；gamma<1 的 analytic bound | 本地推导 §5，以标准 KL/TV 原理推导，未主张新定理 | src/ou_measurement_error.py:231–252 | Bregman 方向、1/4 系数、TV 转移方向、union bound 已核查；数值验证并非证明 |
| 加密采样保证 theta 一致性 | **不成立（V未知时）**；infill 可识别乘积 V theta | 固定紧区间、平稳 OU+white noise；原文参数化 sigma²=本稿 V | [Chen et al.2000 p143；p145 Thm3；Remark7](https://www3.stat.sinica.edu.tw/statistica/oldpdf/A10n17.pdf) | 不属于当前有限网格模拟证明范围 | 原文已核验；原文 p144 Remark4 的显式 CI 是 eta²，不是未知 V 下的 drift CI |

代码相对仓库根目录；永久快照位于各 replay 文件夹的 source_snapshot/。本次已执行：

```text
.venv/bin/python -m pytest tests/test_ou_measurement_error.py tests/test_design_comparison.py -q
30 passed, 11 subtests passed in 36.02s
```

这些验证分别覆盖 dense-covariance、sequential Kalman、orthonormal contrasts、
Fisher 有限差分、Gaussian KL、white-noise limit、两个已知数值缺陷回归例子，
以及独立设计差异界的边界/枚举验证。不是“所有数学命题已获证明/专家认可”。

## 原始文献与区间可比性

| 文献 | 本次核验位置 | 本稿可使用的证据 | 不能直接用来做什么 |
| --- | --- | --- | --- |
| Chen, Simpson & Ying (2000), Statistica Sinica 10,141–156 | 原 PDF p142 Eq1.3；p143 identification；p144 Thm2/Remark4；p145 Thm3/Remark7 | OU+white-noise fixed-domain 模型；V theta 微遍历乘积；eta² 的渐近 CI | 不可把 eta² CI 或已知 drift 条件下 V 的渐近式改名为当前未知 V/mu 的 theta CI |
| [Holý & Tomanová, arXiv:1811.09312](https://arxiv.org/html/1811.09312) | 2025-10-19 v4 HTML，§2.3 Eq19–30，§2.4 | 等间隔 noisy OU 的 ARMA 表示、点估计背景 | 未在所核验内容找到可直接复现的同设定 theta CI；本研究未复制其原论文算法并作优势检验 |
| [Calderon (2013), Phys. Rev. E 88,012707](https://doi.org/10.1103/PhysRevE.88.012707) | [作者公开全文](https://arxiv.org/html/1304.4196)，§I–II 与 innovation likelihood appendix | noisy finite-series confinement/bias-correction 背景 | 点估计偏差修正不是当前研究现成区间基线；未实施其全部 corral-radius 研究 |
| [Li, Kenney & Gu (2026)](https://arxiv.org/html/2605.01262) | §2 Eq1，§2.3 stationary Kalman likelihood，§4.1.2 | 多维 factor OU state-space 与带误差环境应用背景 | 文中 forecast prediction intervals 不是标量 drift confidence intervals；不能当作本稿区间优越性比较 |
| Patterson & Thompson (1971), Biometrika58(3),545–554 | [出版方元数据和摘要](https://academic.oup.com/biomet/article-abstract/58/3/545/233494)已核验；PDF 重定向失败，Edinburgh 作者机构存档全文请求超时 | 仅作为 residual-error-contrast likelihood 的历史归属；本地推导自行列明 | **未完成全文核验**，不得声称已复现作者公式或原文数值 |

没有把已发表点估计研究假设为已实现的区间算法。以上引用不是系统性查新，
不能据此认证原创性。本子报告没有新增“优于上述文献方法”的声称。

## 老师仍需判断的问题

1. 短窗口且 nuisance/边界存在时，是否应把 restricted-likelihood-ratio
   曲线称为 REML profile confidence set？本稿已明确它只是渐近 cutoff 的成员诊断。
2. 可识别性弱或拟合边界时，完整 confidence set 应如何定义，包括空集合、
   不连通集合及无穷端点？当前全量含噪研究没有执行连续反演，不能补称已验证长度。
3. 当前 Gaussian/KL 推导属于标准原理的特定应用；是否足以支持独立论文的理论贡献？
   本稿不主张新估计量、新统一保证或一般最优性。
4. 是否需要预先固定更严格的全局优化核查与独立新种子含噪研究？现有64个预选
   审计和2个事后极端例子不构成每次拟合全局最优的证书。
5. 作者姓名、排序、单位、贡献及通讯安排仍由相关作者确认；孙一帆老师尚未确认
   通讯作者身份。本报告不能替代同意，也不执行投稿或联系。
