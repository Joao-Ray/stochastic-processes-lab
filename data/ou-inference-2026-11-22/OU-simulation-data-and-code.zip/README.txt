Finite-window uncertainty in Ornstein–Uhlenbeck drift inference: a reproducible benchmark
Research data and analysis code accompanying the Statistical Papers submission materials
Hangrui Jiao | Ocean University of China, Qingdao, China

All observations are simulated. This archive contains per-attempt inference outputs, configurations, selected diagnostics, implementations, and selected complete series. Inner bootstrap paths and most latent trajectories can be regenerated from the supplied seeds. Unavailable results, empty sets and infinite endpoints are retained. The existing software licence is in LICENSE.

Paths below are relative to the extracted archive. Write new simulation outputs outside it.

1. subprojects/ou-inference-study/results/{main,confirmation}
   The original benchmark (22,000 main design records plus 2,000 confirmation records). Read replications.csv.gz as a CSV with a header. The adjacent summary.json names scenarios and maps them to configuration parameters. Scripts, seed roles and configurations are in the parent study directory.

2. subprojects/ou-inference-study/audit-2026-11-06/robustness
   Each batch1, batch2 and batch3 directory contains main and confirmation folders. Each has config.json, replications.csv.gz and summary.json. The six files together hold 72,000 scenario records from 24,000 distinct latent trajectories. Join grids only within a batch and duration. Bootstrap draws are inner replicates. The pooled analysis is in analysis.json. width_medians.json in the parent audit directory gives finite-subset medians and their order-statistic Monte Carlo intervals.

3. subprojects/ou-inference-study/audit-2026-11-06/literature
   results contains nine gzipped JSON Lines files for the matched comparison (one object per line). These 18,000 records reuse benchmark paths. The objects retain the slope and method-specific hit, availability, component and endpoint information. Some endpoints and lengths are unbounded; interpret each value with its status and flags. See IMPLEMENTATION.md and summary.json for the construction and denominators.

4. subprojects/ou-inference-study/{finite-sample,measurement-error}/results
   Original stationary-rank study (12,000 plus 4,000) and unknown measurement-error study (7,000 plus 2,000). The latter records true-drift profile membership, point estimation and optimizer diagnostics. It does not contain fully inverted intervals at all replications. Same-seed replays in the paper refer to these original data, which are supplied once.

5. audit-rank-revision/evidence/full_rank_study
   full_sets.jsonl.gz contains 500 reused outer series with all 251 rank-cell decisions per series, accepted components, union lengths and comparison outcomes. The 125,500 decisions are not independent outer observations. The required sparse-design comparison input is duplicated in the original input/unpacked directory layout because the provided run.py opens that relative path.

Integrity
   SHA256SUMS.txt lists the digest of every member except the manifest itself. record_counts.json gives row counts for 22 distinct original record files. The duplicated input in section 5 is not counted twice. To verify all files on macOS or Linux, run shasum -a 256 -c SHA256SUMS.txt from the extracted root.

Reproduction
   Use the versions listed in audit-2026-11-06/environment.lock.txt under the study directory for the original benchmark. The separate 500-record rank-study environment is recorded in its EXECUTION_ENVIRONMENT.json. See requirements.txt for numerical dependencies. In an environment with these installed, from the extracted root:

   python subprojects/ou-inference-study/audit-2026-11-06/reproduce.py --scope all --output ../ou-new-run
   python subprojects/ou-inference-study/audit-2026-11-06/literature/run_comparison.py --output ../ou-comparison
   python subprojects/ou-inference-study/audit-2026-11-06/literature/summarize_comparison.py --input ../ou-comparison --reference-root subprojects/ou-inference-study/audit-2026-11-06/robustness --output ../ou-comparison-report

   To replay the 500-record complete-set study, copy the ENTIRE audit-rank-revision/evidence directory to a fresh location before running run.py and analyze.py from its full_rank_study subdirectory. These two scripts write outputs into their own directory. Gzip metadata and timing fields can change even when the scientific results agree.
